/**
	\file robot.c
	\author Mark Allen Vismonte
	\date Feb 14, 2009
*/

#include "legobot_joystick.c"

/** \brief The main of the LegoBot code.
*/
int main()
{	
	return run_joystick();
}

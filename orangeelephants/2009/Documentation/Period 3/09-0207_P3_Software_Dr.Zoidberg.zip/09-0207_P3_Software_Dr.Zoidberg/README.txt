boolean.h
	Contains preprocessor defines that allow auxiliary use of booleans

legobot_joystick.c
	Contains all test and competition methods to be used for the LegoBot

legobot_joystick.h
	Contains defines and prototypes of methods used in legobot_joystick.c

legobot_motor.c
	Contains mobility methods for the LegoBot

legobot_motor.h
	Contains defines for motor ports & constants and prototypes for methods used
	in legobot_motor.c
	
legobot_sensor.c
	Contains sensor reading methods used for the LegoBot
	
legobot_sensor.h
	Contains defines for sensor ports & other constants and also prototypes of
	the methods used in legobot_sensor.c

math.c
	Contains methods methods of mathematical relevance such as absolute value,
	circle circumference, signums, etc.
	
robot.c
	Contains main method to run our code on LegoBot

DoxygenIndex.html
	The Index for the Code Documentation Document.  The shortcut should work.  
	If it doesn't, please open the index.html file in the html folder.
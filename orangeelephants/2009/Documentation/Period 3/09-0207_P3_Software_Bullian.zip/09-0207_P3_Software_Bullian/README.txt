boolean.h
	Contains preprocessor defines that allow auxiliary use of booleans

controller.c
	Contains code for using the Create with our controller
	
controller.h
		Contains defines for ports/constants also prototypes of functions
		used in controller.c
		
create_constants.h
	Contains various defines of constants for the Create
	
create_motor.c
	Contains mobility functions for the Create
	
create_motor.h
	Contains prototypes of methods used in create_motor.c

math.c
	Contains methods methods of mathematical relevance such as absolute value,
	circle circumference, signums, etc.
	
robot.c
	Contains the different competition methods
	
robot.h
	Contains prototypes of the methods used in robot.c

DoxygenIndex.html
	The Index for the Code Documentation Document.  The shortcut should work.  
	If it doesn't, please open the index.html file in the html folder.
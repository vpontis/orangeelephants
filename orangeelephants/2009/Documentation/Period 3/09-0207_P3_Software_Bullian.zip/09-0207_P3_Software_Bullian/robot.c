#include "create_constants.h"
#include "controller.c"
#include "create_motor.c"
#include "robot.h"
#include "boolean.h"

int main()
{
	kissSim_init(7, 151, 25, 1.5708*3);
	create_connect();
	msleep(5L);
	printf("Choose program to run\nUp: jacob()\nDown: controller()\nLeft: test()\nRight: yixin()\n");
	printf("Choose program to run\nUp: jacob()\nDown: controller()\nLeft: joel()\nRight: yixin()\n");
	printf("A button: vivek()\n");
	while (!(JOYPAD_UP || JOYPAD_DOWN || JOYPAD_RIGHT || JOYPAD_LEFT || a_button()))
		msleep(100L);	
	if(JOYPAD_UP)
		{
			return jacob();
		}
	if(JOYPAD_DOWN)
		{
			return controller();
		}
	if(JOYPAD_LEFT)
		{
			return joel();
		}
	if(JOYPAD_RIGHT)
		{
			return yixin();
		}
	if(a_button())
		{
			return vivek();
		}
	create_disconnect();		
	return 0;	
}

int controller()
{	
	printf("Starting controller method\n");
	enable_servos();
	grab();		
	create_full();
	run_Control();
	return 0;
}	

 int jacob()
{
	printf("Starting jacob method\n");
	enable_servos();
	set_servo_position(LEFTDETACH, 1710);
	set_servo_position(RIGHTDETACH, 210);
	move(-52.0);
	turn_angle(-60.0, 0, 200);
	move(-43.0);
	release();
	msleep(500);
	move(40.0); //move back down slope
	turn_d(-70);
	move_dist(-24. * 2.54, 0, 500);
	turn_d(30);
	move_dist(-24. * 2.54, 0, 500);	
	return 0;
} 

//seeding round method
int joel()
{
	cbc_display_clear();
	printf("Starting vivek-test method\n");
	enable_servos();
	grab();
	printCurrentDist();
	move(-110.0); //gather two tribble cups
	printCurrentDist();	
	turn_speed(300, -90.); //turn 90 slowly to go toward other tribble cup
	move(60.);
	turn_speed(300, -90.); //turn 90 slowly to go toward other tribble cup again
	move(90.);
	turn_speed(300, -90.); //turn 90 slowly to go toward starting box
	move(60.);
	turn_speed(300, -90.); //turn toward botguy
	move(180.); //move toward slope
	turn_speed(300, 90.); //turn toward slope
	move(80.); //move to peak
	msleep(500);
	release();
	turn(-45.);
	turn(45.);
	msleep(1000);
	move(-80.); //move down slope	
	return 0;
}

//ideal double-elimination method
int yixin()
{
	cbc_display_clear();
	printf("Starting yixin-test method\n");
	enable_servos();
	grab();
	printCurrentDist();
	move_forward(110.0);
	printCurrentDist();
	//arc-like thing, without actually arcing
	//turn_angle(-10., 0, 300); //actually 45degrees
	turn_d(45.0);
	msleep(500);
	move_forward(60.0); //test
	//turn_angle(-60., 0, 300); //actually 45degrees
	
	//This is on a slope, so the angle must be increased. 
	turn_speed(300, 65.0); //speed is 300 because it has all the items gathered, needs to be slower.	
	msleep(500);
	move_forward(95.0); //move up to peak
	release();
	msleep(1000);
	//bulldozer gets caught. this movement fixes that.
	turn_d(-45.);
	msleep(250);
	turn_d(45.);
	msleep(500);
	move_backward(90.0); //go back down the slope
	turn_d(160.0); //turn around 180 degrees
	grab(); //close gripper things.
	msleep(500);
	move_forward(120.0); //move toward starting box area.
	msleep(500);
	turn_d(90.0); //turn to starting box area more
	move_forward(25.); //move to starting box area more
	msleep(500);
	turn_d(90.); //turn to starting box.
	msleep(500);
	move_forward(120.); //move into the starting box
	return 0;
} 

//if their robot is going to block the peak, use vivek()
int vivek()
{
	cbc_display_clear();
	printf("Starting vivek-test method\n");
	enable_servos();
	grab();
	printCurrentDist();
	move(110.0); //gather two tribble cups
	printCurrentDist();
	
	turn_speed(300, -90.); //turn 90 slowly to go toward other tribble cup
	move(60.);
	turn_speed(300, -90.); //turn 90 slowly to go toward other tribble cup again
	move(90.);
	turn_speed(300, -90.); //turn 90 slowly to go toward starting box
	move(60.);
	turn_speed(300, 90.); //turn to starting box.
	move(120.); //move into starting box
	release();
	msleep(1000);
	move(-120.); //move out of starting box
	turn(90.);
	move(90.);
	turn(90.); //turn toward opp starting box
	move(180.); //move into starting box and starting ramming process right after this.
	
	
	return 0;
}

void printCurrentDist()
{
	printf("current distance before moving: %d\t%d\n", create_distance(), gc_distance);
}
